<?php
// Conexão com o banco de dados SQLite do projeto
$conexao = new PDO("sqlite:loja.db");

// Selecionando 4 campos usando o nome exato da coluna no banco: nomecliente
$resultado = $conexao->query("SELECT id, nomecliente, email, telefone FROM cliente");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Clientes</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="geral">
        <h2 class="title">Clientes Cadastrados</h2>
        
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Telefone</th>
            </tr>
            <?php while ($linha = $resultado->fetch(PDO::FETCH_ASSOC)) { ?>
                <tr>
                    <td><?php echo $linha['id']; ?></td>
                    <td><?php echo $linha['nomecliente']; ?></td>
                    <td><?php echo $linha['email']; ?></td>
                    <td><?php echo $linha['telefone']; ?></td>
                </tr>
            <?php } ?>
        </table>

        <!-- Menu de navegação integrado -->
     <div>
        <br><br>
         <a href="index.php">Início</a> <br>
         <a href="cliente.php">Cadastrar Cliente</a> <br>
         <a href="consulta_cliente.php">Consultar Clientes</a> <br>
         <a href="consulta_produto.php">Consultar Produtos</a>
     </div>
    </div>
</body>
</html>