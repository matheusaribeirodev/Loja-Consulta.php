<?php
session_start();
// ... código que insere os dados no banco de SQLite ...


try {
    $pdo = new PDO('sqlite:loja.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nomecliente = $_POST['nomecliente'] ?? '';
        $email       = $_POST['email'] ?? '';
        $telefone    = $_POST['telefone'] ?? '';
        $enderecorua = $_POST['enderecorua'] ?? '';
        $numero      = $_POST['numero'] ?? '';
        $complemento = $_POST['complemento'] ?? '';
        $bairro      = $_POST['bairro'] ?? '';
        $cidade      = $_POST['cidade'] ?? '';
        $estado      = $_POST['estado'] ?? '';

        $sql = "INSERT INTO cliente (nomecliente, email, telefone, enderecorua, numero, complemento, bairro, cidade, estado) 
                VALUES (:nomecliente, :email, :telefone, :enderecorua, :numero, :complemento, :bairro, :cidade, :estado)";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nomecliente' => $nomecliente,
            ':email'       => $email,
            ':telefone'    => $telefone,
            ':enderecorua' => $enderecorua,
            ':numero'      => $numero,
            ':complemento' => $complemento,
            ':bairro'      => $bairro,
            ':cidade'      => $cidade,
            ':estado'      => $estado
        ]);

        header('Location: cliente.php?status=sucesso');
        exit;
    }
} catch (PDOException $e) {
    echo "Erro ao cadastrar cliente: " . $e->getMessage();
}
// Exemplo ao finalizar ou redirecionar:
$_SESSION['mensagem'] = "Cadastrado com sucesso!";
session_destroy(); // Encerra a sessão conforme pedido na atividade[cite: 2]
header("location: cliente.php"); // ou produto.php
exit();
?>