<?php
session_start();

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'] ?? '';
    $quantidade = $_POST['quantidade'] ?? '';
    $valor_compra = $_POST['valor_compra'] ?? '';
    $valor_venda = $_POST['valor_venda'] ?? '';

    try {
        // Conexão com o banco SQLite
        $conexao = new PDO("sqlite:loja.db");
        $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Insere na tabela produto (conforme os campos do print: nome, quantidade, valor_compra, valor_venda)
        $sql = "INSERT INTO produto (nome, quantidade, valor_compra, valor_venda) VALUES (:nome, :quantidade, :valor_compra, :valor_venda)";
        $stmt = $conexao->prepare($sql);
        
        $stmt->execute([
            ':nome' => $nome,
            ':quantidade' => $quantidade,
            ':valor_compra' => $valor_compra,
            ':valor_venda' => $valor_venda
        ]);

        $_SESSION['mensagem'] = "Produto cadastrado com sucesso!";
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = "Erro ao cadastrar: " . $e->getMessage();
    }
    
    // Destrói a sessão conforme exigido pela atividade após o processamento
    session_destroy();
}

// Redireciona de volta para a página de produto
header("location: produto.php");
exit();
?>