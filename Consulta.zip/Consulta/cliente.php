<?php   
session_start();  
?>  
<!DOCTYPE html>  
<html lang="pt-br">  
<head>  
 <meta charset="UTF-8">  
 <meta name="viewport" content="width=device-width, initial-scale=1.0">  
 <title>Cadastro de cliente</title>  
 <link rel="stylesheet" href="estilo.css">
</head>  
<body>  
 <div class="geral">
     <h2 class="title">Cadastro de Cliente</h2>
     <h3>  
     <?php   
     if(isset($_SESSION["mensagem"])){  
         echo $_SESSION["mensagem"];  
         unset($_SESSION["mensagem"]);  
     } else {  
         echo "&nbsp;";   
     }  
      
     $nome = $_SESSION["nome"] ?? "";  
     $telefone = $_SESSION["telefone"] ?? "";  
     $email = $_SESSION["email"] ?? "";  
     ?>  
     </h3>  
      
     <form action="dados_cliente.php" method="POST">  
     <table>  
     <tr>  
         <td><label>Nome: </label></td>  
         <td><input type="text" name="nome" value="<?php echo $nome; ?>"></td>  
     </tr>  
     <tr>  
         <td><label>Telefone: </label></td>  
         <td><input type="text" name="telefone" value="<?php echo $telefone; ?>"></td>  
     </tr>  
     <tr>  
         <td><label>Email: </label></td>  
         <td><input type="text" name="email" value="<?php echo $email; ?>"></td>  
     </tr>  
     </table>  
     <input type="submit" value="Cadastrar">  
     </form>  
     
     <!-- Menu de navegação integrado -->
     <div>
        <br><br>
         <a href="index.php">Início</a> <br>
         <a href="cliente.php">Cadastrar Cliente</a> <br>
         <a href="consulta_cliente.php">Consultar Clientes</a> <br>
         <a href="consulta_produto.php">Consultar Produtos</a>
     </div>
 </div>
 
 <?php session_unset(); ?>  
</body>  
</html>