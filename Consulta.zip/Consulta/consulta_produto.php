<?php
// Conexão com o banco de dados SQLite do projeto
$conexao = new PDO("sqlite:loja.db");
$resultado = $conexao->query("SELECT * FROM produto");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Produtos</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="geral">
        <h2 class="title">Produtos Cadastrados</h2>
        
        <table border="1">
            <tr >
                <th>ID</th>
                <th>Nome</th>
                <th>Quantidade</th>
                <th>Valor de Compra</th>
                <th>Valor de Venda</th>
            </tr>
            <?php while ($linha = $resultado->fetch(PDO::FETCH_ASSOC)) { ?>
                <tr>
                    <td><?php echo $linha['id']; ?></td>
                    <td><?php echo $linha['nome']; ?></td>
                    <td><?php echo $linha['quantidade']; ?></td>
                    <td>R$ <?php echo number_format($linha['valor_compra'], 2, ',', '.'); ?></td>
                    <td>R$ <?php echo number_format($linha['valor_venda'], 2, ',', '.'); ?></td>
                </tr>
            <?php } ?>
        </table>

        <!-- Menu de navegação integrado -->
     <div>
        <br><br>
         <a href="index.php">Início</a> <br>
         <a href="cliente.php">Cadastrar Cliente</a> <br>
         <a href="consulta_cliente.php">Consultar Clientes</a> <br>
         <a href="consulta_produto.php">Consultar Produtos</a>
     </div>
    </div>
</body>
</html>