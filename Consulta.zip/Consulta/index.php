<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Início - Loja</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="geral">
        <h1 class="title">Minha Loja</h1>
        <p class="text" >Seja bem-vindo à Loja! Utilize o menu abaixo para navegar entre os cadastros e consultas.</p>
        
        <!-- Menu de navegação integrado -->
     <div>
        <br><br>
         <a href="index.php">Início</a> <br>
         <a href="cliente.php">Cadastrar Cliente</a> <br>
         <a href="consulta_cliente.php">Consultar Clientes</a> <br>
         <a href="consulta_produto.php">Consultar Produtos</a>
     </div>
    </div>
</body>
</html>