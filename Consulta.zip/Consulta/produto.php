<?php   
session_start();  
?>  
<!DOCTYPE html>  
<html lang="pt-br">  
<head>  
 <meta charset="UTF-8">  
 <meta name="viewport" content="width=device-width, initial-scale=1.0">  
 <title>Cadastro de Produto</title>  
 <link rel="stylesheet" href="estilo.css">
</head>  
<body>  
 <div class="geral">
     <h2 class="title">Cadastro de Produto</h2>
     <h3>  
     <?php   
     if(isset($_SESSION["mensagem"])){  
         echo $_SESSION["mensagem"];  
         unset($_SESSION["mensagem"]);  
     } else {  
         echo "&nbsp;";   
     }  
     ?>  
     </h3>  
      
     <form action="dados_produto.php" method="POST">  
     <table>  
     <tr>  
         <td><label>Nome do Produto: </label></td>  
         <td><input type="text" name="nome"></td>  
     </tr>  
     <tr>  
         <td><label>Quantidade: </label></td>  
         <td><input type="text" name="quantidade"></td>  
     </tr>  
     <tr>  
         <td><label>Valor de Compra (R$): </label></td>  
         <td><input type="text" name="valor_compra"></td>  
     </tr>  
     <tr>  
         <td><label>Valor de Venda (R$): </label></td>  
         <td><input type="text" name="valor_venda"></td>  
     </tr>  
     </table>  
     <input type="submit" value="Cadastrar Produto">  
     </form>  

     <!-- Menu de navegação integrado -->
     <div>
        <br><br>
         <a href="index.php">Início</a> <br>
         <a href="cliente.php">Cadastrar Cliente</a> <br>
         <a href="consulta_cliente.php">Consultar Clientes</a> <br>
         <a href="consulta_produto.php">Consultar Produtos</a>
     </div>
 </div>
 
 <?php session_unset(); ?>  
</body>  
</html>